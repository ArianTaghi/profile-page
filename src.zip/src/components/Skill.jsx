import React from 'react'
import Header from './Header.jsx'
import { DiJava, DiPhotoshop, DiIllustrator } from "react-icons/di"

const Skill = () => {
  return (
    <div className="page-shell">
      <main className="placeholder-page">
        <div>Skill</div>
        <i class="devicon-java-plain colored"></i>
        <i class="devicon-photoshop-plain colored"></i>
        <i class="devicon-illustrator-plain colored"></i>
      </main>
    </div>
  )
}

export default Skill
