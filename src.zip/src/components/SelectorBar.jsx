import React from 'react'

const SelectorBar = ({ onSelect }) => {
    
  return (
    <div>
        <button onClick={() => onSelect("Home")}>مهارت</button>
        <button onClick={() => onSelect("Contact")}>ارتباط</button>
        <button onClick={() => onSelect("Sample")}>نمونه کار</button>

    </div>
  )
}

export default SelectorBar