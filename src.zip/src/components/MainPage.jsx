import React, { useState } from 'react'
import About from './About.jsx'
import Contact from './Contact.jsx'
import Skill from './Skill.jsx'
import SelectorBar from './SelectorBar.jsx'

const MainPage = () => {

    const [active, setActive] = useState("");
    const handleSelect = (word) => {
        setActive(word);
    };

return (
  <div>
      <About/>
      <div>
        <SelectorBar onSelect={handleSelect} >
        </SelectorBar>
        {<Skill/> && active === "Skill"}
        {<Contact/> && active === "Contact"}
        {<About/> && active === "About"}
      </div>
    </div>
  )
}

export default MainPage