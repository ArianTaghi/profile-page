import React from 'react'

const LinkSheet = ({link, name}) => {
  return (
        <i className={`devicon-${name}-plain colored`}
            onClick={() => window.open(link, "_blank")}>
        </i>
    )
}

export default LinkSheet