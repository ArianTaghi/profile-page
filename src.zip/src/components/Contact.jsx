import React from 'react'
import Header from './Header.jsx'
import LinkSheet from './LinkSheet.jsx'
const Contact = () => {
  const goToLink = (link) => {
    {() => window.open(link, "_blank")}
  }
  return (
    <div className="page-shell">
      <main className="placeholder-page">
        <div>ارتباط با من:</div>
        <div>
          <div>
            ایمیل:
          </div>
          <div>
            arian.taghi@gmail.com
          </div>
        </div>
        <div>
            <div>
              گیت هاب:
            </div>
            <div>
              ArianTaghi
            </div>
        </div>
        <div>
          <div> 
            لینکدین:
          </div>
          <div>
            Arian Taghi
          </div>
        </div>
        <div>
          <LinkSheet link={"https://github.com/ArianTaghi"} name={"github"}/>
          <LinkSheet link={"https://www.linkedin.com/in/arian-taghi-968a74420/"} name={"linkedin"}/>
          <LinkSheet link={"https://www.arian.taghi@gmail.com"} name={"google"}/>
        </div>
      </main>
    </div>
  )
}

export default Contact
