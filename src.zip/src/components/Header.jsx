import React from 'react'
import HeaderButton from './HeaderButton'
import { useNavigate } from 'react-router-dom'

const Header = () => {
  const navigate = useNavigate();

  return (
    <header className="site-header">
      <div className="header-inner">
        <label className="header-brand" onClick={() => navigate("/")}>Arian Taghi</label>
        <nav className="header-nav" aria-label="منوی اصلی">
          <HeaderButton dest="/" name="Me" />
          <HeaderButton dest="/weblog" name="وبلاگ" />
        </nav>
      </div>
    </header>
  )
}

export default Header
