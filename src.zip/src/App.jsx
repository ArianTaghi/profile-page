import './App.scss'
import Header from './components/Header.jsx'
import MainPage from './components/MainPage.jsx'

import { useState } from 'react'

function App() {
  
  const [active, setActive] = useState("");
  
  return (
    <div>
      <Header/>
      <MainPage/>
    </div>
  )
}

export default App
